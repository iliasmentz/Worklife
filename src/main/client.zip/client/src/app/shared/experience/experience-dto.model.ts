export class ExperienceDto {
  title: string;
  company: string;
  startDate: Date;
  endDate: Date;
}
