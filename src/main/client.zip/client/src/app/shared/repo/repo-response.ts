export interface RepoResponse {
  header: Object;
  data: Object;
  error: Object
}
