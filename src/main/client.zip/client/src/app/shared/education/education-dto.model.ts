export class EducationDto {
  universityDegree: string;
  universityName: string;
  startingDate: Date;
  endingDate: Date;
}

